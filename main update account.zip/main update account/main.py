from telethon.sync import TelegramClient,events,functions,errors
from telethon.tl.custom import Button
from lxml import html
import psutil,requests,os,json,subprocess
for item in ['Accounts','Api']:
    if not os.path.exists(item):
        os.mkdir(item)
bot = TelegramClient('bot',1581224,'bd891fcb8726cfbd64abc9ddbba2c8ff')
bot.start()
print(f'Bot Launched On @{(bot.get_me()).username} Successfully! ')
admins = [2024674816,2024674816]
data = dict()
#Functions
def get_api(phone):
    try:
        with open(f'Api/{phone}.txt','r') as fd:
            content = fd.read()
            fd.close()
            return [content.split(':')[0],content.split(':')[1]]
    except FileNotFoundError:
        return 0
def status():
    m = [[Button.inline('Cpu Percentage'),Button.inline(f'{psutil.cpu_percent()}%')],[Button.inline('Ram Usage'),Button.inline(f'{psutil.virtual_memory().percent}%')],[Button.inline('Refresh')],[Button.inline('Close')]]
    return m
def accounts():
    ev = []
    tl = 0 
    ev.extend([[Button.inline('   ')]])
    for item in os.scandir('Accounts'):
        if 'journal' not in item.name and '.session' in item.name:
            l = [[Button.inline(item.name.split('.session')[0],f'settings|{item.name}')]]
            ev.extend(l)
            tl +=1
    ev.extend([[Button.inline('   ')]])
    ev.extend([[Button.inline('Close')]])
    if tl >= 1:
        return ev
    else:
        return None
def create_api(phone):
    body = 'phone={0}'.format(phone)
    try:
        response = requests.post('https://my.telegram.org/auth/send_password',data=body,headers= {"Origin":"https://my.telegram.org","Accept-Encoding": "gzip, deflate, br","Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4","User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","Accept": "application/json, text/javascript, */*; q=0.01","Reffer": "https://my.telegram.org/auth","X-Requested-With": "XMLHttpRequest","Connection":"keep-alive","Dnt":"1",})
        s = json.loads(response.content)
        return s['random_hash']
    except:
        return False
def auth(phone,hash_code,pwd):
    data2 = "phone={0}&random_hash={1}&password={2}".format(phone,hash_code,pwd)
    responses = requests.post('https://my.telegram.org/auth/login',data=data2,headers= {"Origin":"https://my.telegram.org","Accept-Encoding": "gzip, deflate, br","Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4","User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","Accept": "application/json, text/javascript, */*; q=0.01","Reffer": "https://my.telegram.org/auth","X-Requested-With": "XMLHttpRequest","Connection":"keep-alive","Dnt":"1",})
    try:
        return responses.cookies['stel_token']
    except:
        return False
def auth2(stel_token):
    resp = requests.get('https://my.telegram.org/apps',headers={"Dnt":"1","Accept-Encoding": "gzip, deflate, br","Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4","Upgrade-Insecure-Requests":"1","User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36","Reffer": "https://my.telegram.org/org","Cookie":"stel_token={0}".format(stel_token),"Cache-Control": "max-age=0",})
    tree = html.fromstring(resp.content)
    api = tree.xpath('//span[@class="form-control input-xlarge uneditable-input"]//text()')
    try:
        return '{0}:{1}'.format(api[0],api[1])
    except:
        s = resp.text.split('"/>')[0]
        value = s.split('<input type="hidden" name="hash" value="')[1]
        on = "hash={0}&app_title=Coded By Arash&app_shortname=Love Telegram&app_url=&app_platform=desktop&app_desc=".format(value)
        requests.post('https://my.telegram.org/apps/create',data=on,headers={"Cookie":"stel_token={0}".format(stel_token),"Origin": "https://my.telegram.org","Accept-Encoding": "gzip, deflate, br","Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4","User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","Accept": "*/*","Referer": "https://my.telegram.org/apps","X-Requested-With": "XMLHttpRequest","Connection":"keep-alive","Dnt":"1",})
        respv = requests.get('https://my.telegram.org/apps',headers={"Dnt":"1","Accept-Encoding": "gzip, deflate, br","Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4","Upgrade-Insecure-Requests":"1","User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36","Reffer": "https://my.telegram.org/org","Cookie":"stel_token={0}".format(stel_token),"Cache-Control": "max-age=0",})
        trees = html.fromstring(respv.content)
        apis = trees.xpath('//span[@class="form-control input-xlarge uneditable-input"]//text()')
        return '{0}:{1}'.format(apis[0],apis[1])
#handler
@bot.on(events.NewMessage(from_users=admins))
async def newmsg(event):
    if event.raw_text.lower() == '/ping':
        await event.reply('**Im Online!**',buttons = status())
    elif event.raw_text.startswith('info'):
        st = psutil.pid_exists(int(event.raw_text.split('info ')[1]))
        if st == True:
            await event.reply('Still Online!')
        elif st == False:
            await event.reply('Pid is killed!')
    elif event.raw_text.startswith('kill'):
        pk = event.raw_text.split('kill ')[1]
        if pk.isdigit():
            w = os.system(f'kill -9 {pk}')
            if w == 0:
                await event.reply('PID Killed Successfully !')
            else:
                await event.reply('PID Not found')
        else:
            await event.reply('PID is number not str or ...')
        
    elif event.raw_text.lower() == '/accounts':
        acc = accounts()
        if acc != None:
            await event.reply(f'You can see all {len(acc)-3} Accounts Here!',buttons=acc)
        else:
            await event.reply('Accounts list is empty!')
    elif event.raw_text.lower().startswith('/login'):
        phones = event.raw_text.split('/login ')[1].replace(' ','')
        if os.path.exists('Accounts/{0}.session'.format(phones)):
            await event.reply('**Account Already In Database !**')
        else:
            await event.reply('**Please Wait...**')
            result = create_api(phones)
            if result == False:
                await event.reply('**We Have Some Errors To Send Code For {} !**'.format(phones))
            else:
                await event.reply('**Authunication Code Successfully Sended To {0}\nPlease Enter Code With This Format /auth CODE**'.format(event.raw_text.split('/login ')[1]))
                data['auth_mode'] = '{0}:{1}'.format(phones,result)
    elif event.raw_text.lower().startswith('/auth'):
        try:
            key = data['auth_mode']
            await event.reply('**Please Wait ... **')
            result = auth(key.split(':')[0],key.split(':')[1],event.raw_text.split('/auth ')[1])
            if result == False:
                await event.reply('**We Have Some Errors For Create Api Please Try Again Later ...**')
                data.clear()
            else:
                await event.reply('**Done Account Loginned Successfully Please Wait...**')
                api_info = auth2(result)
                await event.reply('**Done Api [{0}] Created Successfully !\nPlease Wait For Send Code...**'.format(api_info))
                with open('Api/{0}.txt'.format(key.split(':')[0]),'w') as file:
                    file.write('{0}:{1}'.format(api_info.split(':')[0],api_info.split(':')[1]))
                    file.close()
                data.clear()
                new =  TelegramClient('Accounts/{0}'.format(key.split(':')[0]),int(api_info.split(':')[0]),api_info.split(':')[1])
                await new.connect()
                if not await new.is_user_authorized():
                    try:
                        result = await new.send_code_request(key.split(':')[0])
                        data['code_mode'] = '{0}:{1}:{2}:{3}'.format(key.split(':')[0],result.phone_code_hash,api_info.split(':')[0],api_info.split(':')[1])
                        await new.disconnect()
                        await event.reply('**Done Code Sended Please Enter Code With This Format /code CODE **')
                    except Exception:
                        await event.reply('**Error In Send Code Please Try Again Later...**')
        except KeyError:
            await event.reply('** No Any Account In Queue**')
    elif event.raw_text.lower().startswith('/code'):
        try:
            key = data['code_mode']
            await event.reply('**Please Wait ... **')
            new =  TelegramClient('Accounts/{0}'.format(key.split(':')[0]),int(key.split(':')[2]),key.split(':')[3])
            await new.connect()
            await new(functions.auth.SignInRequest(phone_number=key.split(':')[0],phone_code_hash=key.split(':')[1],phone_code=event.raw_text.split('/code ')[1]))
            await event.reply('**Done Account Loginned Successfully!**')
            data.clear()
        except errors.SessionPasswordNeededError:
            await event.reply('**Session Need Password Please Enter Password With This Format /step PASSWORD**')
            data.clear()
            data['step_mode'] = key
        except KeyError:
            await event.reply('** No Any Account In Queue**')
        await new.disconnect()
    elif event.raw_text.lower().startswith('/step'):
        try:
            key = data['step_mode']
            await event.reply('**Please Wait ... **')
            k2 = get_api(key.split(':')[0])
            new =  TelegramClient('Accounts/{0}'.format(key.split(':')[0]),int(k2[0]),k2[1])
            await new.connect()
            await new.sign_in(password=event.raw_text.split('/step ')[1])
            data.clear()
            info = await new.get_me()
            await new.disconnect()
            await event.reply('**Done Api [{0}] Successfully Added To Database !\nAccount Info\nAccount Username : {1}\nAccount Phone : +{2}\nAccount FirstName : {3}\nAccount LastName : {4}**'.format(key.split(':')[2]+':'+key.split(':')[3],str(info.username),str(info.phone),info.first_name,info.last_name))
        except KeyError:
            await event.reply('** No Any Account In Queue**')
        except errors.PasswordHashInvalidError:
            await event.reply('** Password Is Invalid Please Enter True Password With This Format /step PASSWORD**')
        await new.disconnect()
    elif event.raw_text.lower().startswith('launch'):
        key = event.raw_text.split('launch ')[1]
        msg = await event.reply('Please Wait ...')
        path = os.getcwd()
        os.system(f"screen -dm bash -c 'python3 Plugins/bot.py {key} {event.chat_id}'")
        await msg.edit('Launched Successfully!')
@bot.on(events.CallbackQuery)
async def newcall(events):
    callback = events.data.decode()
    if events.sender_id in admins:
        if callback == 'Close':
            await events.edit('Closed')
        elif callback == 'Refresh':
            await events.answer('Updated!')
            await events.edit('**Im Online!**',buttons = status())
        elif callback.startswith('settings'):
            phn = callback.split('|')[1]
            await events.reply(f'What you want with {phn} ?',buttons = [[Button.inline('Delete',f'delete|{phn}'),Button.inline('Close')]])
        elif callback.startswith('delete'):
            pehen = callback.split('|')[1]
            try:
                os.remove(f'Accounts/{pehen}')
                await events.edit(f'Done Account {pehen} Successfully Removed From Database!')
            except :
                await events.edit(f'I cant delete {pehen} From database ! Try Again later...')
bot.run_until_disconnected()