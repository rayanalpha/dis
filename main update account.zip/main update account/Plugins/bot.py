import os,sys,requests,psutil,time,redis,random,sqlite3,datetime
from telethon.sync import TelegramClient,functions,types,events,errors
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.channels import LeaveChannelRequest
link = 'https://t.me/joinchat/4qJmPyQT2uQ2ZjFk'
token = 'https://t.me/+oPEytxvg0q1jMmRk'
admins = [2024674816,2024674816]
for item in ['Databases']:
    if not os.path.exists(item):
        os.mkdir(item)
loop = redis.Redis(host='localhost', port=6379, db=0)
loop.set(os.getpid(),0)
def get_api(phone):
    try:
        with open(f'Api/{sys.argv[1]}.txt','r') as fd:
            content = fd.read()
            fd.close()
            return [content.split(':')[0],content.split(':')[1]]
    except FileNotFoundError:
        return 0
api = get_api(sys.argv[1])
bot = TelegramClient(f'Accounts/{sys.argv[1]}',api[0],api[1])
bot.connect()
if bot.is_user_authorized():
    requests.post(f'https://api.telegram.org/bot{token}/sendMessage',data={'chat_id': sys.argv[2], 'text' : f'Bot Launched With PID {os.getpid()}'})
    my_phone = (bot.get_me()).phone
else:
    requests.post(f'https://api.telegram.org/bot{token}/sendMessage',data={'chat_id': sys.argv[2], 'text' : 'Some Errors In login To Account'})
    sys.exit()
try:
    bot(functions.messages.ImportChatInviteRequest(hash=link.split('/')[-1]))
except:
    pass
db = sqlite3.connect(f'Databases/{sys.argv[1]}.db')
m = db.cursor()
try:
    m.execute('''CREATE TABLE usernames 
             ( username,channel )''')#create table
except sqlite3.OperationalError:
    pass
try:
    m.execute('''CREATE TABLE banned 
             ( username,channel )''')#create table
except sqlite3.OperationalError:
    pass
async def add_id(username,target,is_banned):
    try:
        if is_banned:
            m.execute('INSERT INTO banned VALUES (?,?)',(username,target,))
        else:
            m.execute('INSERT INTO usernames VALUES (?,?)',(username,target,))
        db.commit()
        return True
    except:
        return False
async def is_avilable(username,is_banned):
    if is_banned:
        m.execute('SELECT * FROM banned WHERE username = ?',(username,))
    else:
        m.execute('SELECT * FROM usernames WHERE username = ?',(username,))
    if m.fetchone() != None:
        return True
    else:
        return False
async def delete_id(username,is_banned):
    if is_banned:
        m.execute('DELETE FROM banned WHERE username=?',(username,))
    else:
        m.execute('DELETE FROM usernames WHERE username=?',(username,))
    db.commit()
    return True
@bot.on(events.NewMessage(from_users=admins))
async def newmsg(event):
    if event.raw_text.lower() == 'ping':
        await event.reply(f'**Im Online!**\nCpu Usage : {psutil.cpu_percent()}%\nRam Usage : {psutil.virtual_memory().percent}%\nPID : {os.getpid()}\nAccount Phone : +{my_phone}\n\n➖➖➖➖➖➖➖➖\nTemprory Commands For Run :\n`launch +{my_phone}`\n`kill {os.getpid()}`')
    elif event.raw_text.lower() == 'list':
        msg = await event.reply('Please Wait...')
        i = 1
        channels = []
        txt = '➖➖➖➖➖➖➖➖'
        async for channel in bot.iter_dialogs():
            if channel.is_channel:
                if channel.entity.creator:
                    if channel.entity.username != None:
                        txt+= f'\n{i} - {channel.title} `{channel.id}` @{channel.entity.username}\n➖➖➖➖➖➖➖➖'
                    else:
                        txt+= f'\n{i} - {channel.title} `{channel.id}`\n➖➖➖➖➖➖➖➖'
                    i+=1
        await msg.edit(txt)
    elif event.raw_text.lower().startswith('remove'):
        key = event.raw_text.lower().split('remove ')[1]
        msg = await event.reply(f'Please Wait for get entity from {key}')
        try:
            left = await bot.get_entity(int(key))
            await bot(LeaveChannelRequest(left))
            await msg.edit(f'ℹ️ Channel {left.title}  {left.id} Deleted.')
        except:
            await msg.edit(f'I cant find entity for {key} .')
    elif event.raw_text.lower().startswith('new'):
        key = event.raw_text.lower().split(' ')
        msg = await event.reply('Please Wait...')
        try:
            channel = await bot(functions.channels.CreateChannelRequest(title=key[1],about=key[2],megagroup=False))
            await msg.edit(f'Channel `{channel.updates[1].channel_id}` Created Successfully!\nTitle : {key[1]}\nAbout : {key[2]}')
        except:
            await msg.edit(f'Some Errors in create channel')
    elif event.raw_text.lower().startswith('/setban'):
        key = event.raw_text.lower().split(' ')
        #key[1] == 'USERNAME'
        #key[2] == 'channel'
        if len(key) == 3:
            if len(key[1]) >= 5:
                killer = await is_avilable(key[1].lower(),True)
                if killer == False:
                    try:
                        etelaat = await bot.get_entity(int(key[2]))
                        await add_id(key[1].lower(),int(key[2]),True)
                        await event.reply(f'Id @{key[1]} successfully seted to {key[2]}')
                    except Exception as e :
                        await event.reply(f'I cant find entity for {key[2]} .\n\n{e}')
                else:
                    await event.reply('Id is avilable in database!')
            else:
                await event.reply('ID Lenght is low.')
        else:
            await add_id(key[1].lower(),0,True)
            await event.reply(f'Id @{key[1]} successfully seted to account.')
    elif event.raw_text.lower().startswith('/unsetban'):
        key = event.raw_text.lower().split('/unsetban ')[1]
        if key == 'all':
            m.execute('DELETE FROM banned;')
            db.commit()
            await event.reply('Done All Usernames Deleted from database.')
        if len(key) >= 5:
            killer = await is_avilable(key.lower(),True)
            if killer == True:
                await delete_id(key.lower(),True)
                await event.reply(f'Id @{key} successfully Delete from list')
            else:
                await event.reply('Id is not avilable in database!')
        else:
            await event.reply('ID Lenght is low.')
    elif event.raw_text.lower().startswith('/set'):
        key = event.raw_text.lower().split(' ')
        #key[1] == 'USERNAME'
        #key[2] == 'channel'
        if len(key) == 3:
            if len(key[1]) >= 5:
                killer = await is_avilable(key[1].lower(),False)
                if killer == False:
                    try:
                        etelaat = await bot.get_entity(int(key[2]))
                        await add_id(key[1].lower(),int(key[2]),False)
                        await event.reply(f'Id @{key[1]} successfully seted to {key[2]}')
                    except Exception as e :
                        await event.reply(f'I cant find entity for {key[2]} .\n\n{e}')
                else:
                    await event.reply('Id is avilable in database!')
            else:
                await event.reply('ID Lenght is low.')
        else:
            await add_id(key[1].lower(),0,False)
            await event.reply(f'Id @{key[1]} successfully seted to account.')
    elif event.raw_text.lower().startswith('/unset'):
        key = event.raw_text.lower().split('/unset ')[1]
        if key == 'all':
            m.execute('DELETE FROM usernames;')
            db.commit()
            await event.reply('Done All Usernames Deleted from database.')
        elif len(key) >= 5:
            killer = await is_avilable(key.lower(),False)
            if killer == True:
                await delete_id(key.lower(),False)
                await event.reply(f'Id @{key} successfully Delete from list')
            else:
                await event.reply('Id is not avilable in database!')
        else:
            await event.reply('ID Lenght is low.')
    elif event.raw_text.lower().startswith('idlist'):
        key = event.raw_text.lower().split('idlist ')[1]
        if int(key) == 1:
            m.execute('SELECT * FROM usernames;')
            ww = m.fetchall()
            if ww != []:
                i = 1
                txt = 'Username’s List\n➖➖➖➖➖➖➖➖'
                for item in ww:
                    if item[1] == 0:
                        txt += f'\n{i}-@{item[0]}\n➖➖➖➖➖➖➖➖'
                    else:
                        txt += f'\n{i}-@{item[0]} `{item[1]}`\n➖➖➖➖➖➖➖➖'
                    i+=1
                await event.reply(txt)
            else:
                await event.reply('List Is Empty!')
        elif int(key) == 2:
            m.execute('SELECT * FROM banned;')
            ww = m.fetchall()
            if ww != []:
                i = 1
                txt = 'Username’s List\n➖➖➖➖➖➖➖➖'
                for item in ww:
                    if item[1] == 0:
                        txt += f'\n{i}-@{item[0]}\n➖➖➖➖➖➖➖➖'
                    else:
                        txt += f'\n{i}-@{item[0]} `{item[1]}`\n➖➖➖➖➖➖➖➖'
                    i+=1
                await event.reply(txt)
            else:
                await event.reply('List Is Empty!')
        else:
            await event.reply('Please Enter 1 For Normal List\nPlease Enter 2 For Banned list.')
    elif event.raw_text.lower() == 'start':
        msg = await event.reply('Please Wait...')
        m.execute('SELECT * FROM usernames;')
        w = m.fetchall()
        if len(w) != 0:
            tgts = [its[0] for its in w]
            pnl = dict()
            for chan in w:
                pnl[chan[0]] = chan[1]
            await msg.edit(f'Process Started With {len(tgts)} Usernames...')
            loop.set(os.getpid(),1)
            while (loop.get(os.getpid()).decode()) == '1':
                if len(tgts) != 0:
                    for _username in tgts:
                        try:
                            await bot(functions.messages.GetPeerDialogsRequest(peers=[_username])) 
                        except errors.rpcerrorlist.UsernameInvalidError:
                            await delete_id(_username,False)
                            await event.reply(f'ID @{_username} Banned! i delete it form list!')
                            continue
                        except ValueError:
                            try:
                                if pnl[_username] != 0:
                                    chl = await bot.get_entity(pnl[_username])
                                    await bot(functions.channels.UpdateUsernameRequest(channel=chl,username=_username))
                                else:
                                    await bot(functions.account.UpdateUsernameRequest(username=_username))
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Taked Successfully!')
                            except Exception:
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Lost Beacause I cant set it.')
                            continue
                        except KeyError:
                            try:
                                if pnl[_username] != 0:
                                    chl = await bot.get_entity(pnl[_username])
                                    await bot(functions.channels.UpdateUsernameRequest(channel=chl,username=_username))
                                else:
                                    await bot(functions.account.UpdateUsernameRequest(username=_username))
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Taked Successfully!')
                            except Exception:
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Lost Beacause I cant set it.')
                            continue
                        except Exception as et:
                            try:
                                if pnl[_username] != 0:
                                    chl = await bot.get_entity(pnl[_username])
                                    await bot(functions.channels.UpdateUsernameRequest(channel=chl,username=_username))
                                else:
                                    await bot(functions.account.UpdateUsernameRequest(username=_username))
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Taked Successfully!')
                            except Exception as bit:
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Lost Beacause I cant set it.\nError1 : {et}\nError2: {bit}')
                            continue
                        except errors.FloodWaitError as e3:
                            t = str(datetime.timedelta(seconds=e3.seconds))
                            await event.reply(f'Account `+{my_phone}` Have Flood Wait ...\nTime : {t}')
                            sys.exit()
                else:
                    loop.set(os.getpid(),0)
                    await event.reply('Done All Usernames ')
                    break
        else:
            await msg.edit('Usernames List is empty!')
    elif event.raw_text.lower() == 'stop':
        if loop.get(os.getpid()).decode() == '1':
            loop.set(os.getpid(),0)
            await event.reply('Process Stopped!')
        else:
            await event.reply('Not Started process yet')
    elif event.raw_text.lower() == 'help':
        if loop.get(int(time.time())) == None:
            loop.set(int(time.time()) ,'Done')
            await event.reply('➖➖➖➖➖➖➖➖\n`help`\n\n**Get Cli Bot Commands List**\n➖➖➖➖➖➖➖➖\n`ping`\n\n**Check bot status**\n➖➖➖➖➖➖➖➖\n`list`\n\n**Get Channels List**\n➖➖➖➖➖➖➖➖\n`new title DESCRIPTION`\n\n**Create New Channel**\n➖➖➖➖➖➖➖➖\n`remove CHANNEL`\n\n**Delete / Left From channel**\n➖➖➖➖➖➖➖➖\n`/setban USERNAME CHANNEL`\n\n**Set id in banned list**\n➖➖➖➖➖➖➖➖\n`/unsetban USERNAME`\n\n**Unset Username from banned list**\n➖➖➖➖➖➖➖➖\n`/set USERNAME CHANNEL`\n\n**Set id in normal list**\n➖➖➖➖➖➖➖➖\n`/unset USERNAME`\n\n**Unset id from normal list**\n➖➖➖➖➖➖➖➖\n`idlist` 1 or 2\n\n**send 1 for see normal list / send 2 for see banned list**\n➖➖➖➖➖➖➖➖\n`start`\n\n**Start Normal ids process**\n➖➖➖➖➖➖➖➖\n`stop`\n\n**Stop Normal / Banned process**\n➖➖➖➖➖➖➖➖\n`startban`\n\n**Start Banned ids process**\n➖➖➖➖➖➖➖➖')
    elif event.raw_text.lower() == 'startban':
        msg = await event.reply('Please Wait...')
        m.execute('SELECT * FROM banned;')
        w = m.fetchall()
        if len(w) != 0:
            tgts = [its[0] for its in w]
            pnl = dict()
            for chan in w:
                pnl[chan[0]] = chan[1]
            await msg.edit(f'Process Started With {len(tgts)} Usernames...')
            loop.set(os.getpid(),1)
            while (loop.get(os.getpid()).decode()) == '1':
                if len(tgts) != 0:
                    for _username in tgts:
                        try:
                            await bot(functions.messages.GetPeerDialogsRequest(peers=[_username])) 
                        except errors.rpcerrorlist.UsernameInvalidError:
                            continue
                        except ValueError:
                            try:
                                if pnl[_username] != 0:
                                    chl = await bot.get_entity(pnl[_username])
                                    await bot(functions.channels.UpdateUsernameRequest(channel=chl,username=_username))
                                else:
                                    await bot(functions.account.UpdateUsernameRequest(username=_username))
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Taked Successfully!')
                            except Exception:
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Lost Beacause I cant set it.')
                            continue
                        except KeyError:
                            try:
                                if pnl[_username] != 0:
                                    chl = await bot.get_entity(pnl[_username])
                                    await bot(functions.channels.UpdateUsernameRequest(channel=chl,username=_username))
                                else:
                                    await bot(functions.account.UpdateUsernameRequest(username=_username))
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Taked Successfully!')
                            except Exception:
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Lost Beacause I cant set it.')
                            continue
                        except Exception as et:
                            try:
                                if pnl[_username] != 0:
                                    chl = await bot.get_entity(pnl[_username])
                                    await bot(functions.channels.UpdateUsernameRequest(channel=chl,username=_username))
                                else:
                                    await bot(functions.account.UpdateUsernameRequest(username=_username))
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Taked Successfully!')
                            except Exception:
                                tgts.remove(_username)
                                await delete_id(_username,False)
                                await event.reply(f'ID @{_username} Lost Beacause I cant set it.\nError: {et}')
                            continue       
                        except errors.FloodWaitError as e3:
                            t = str(datetime.timedelta(seconds=e3.seconds))
                            await event.reply(f'Account `+{my_phone}` Have Flood Wait ...\nTime : {t}')
                            sys.exit()
                else:
                    loop.set(os.getpid(),0)
                    await event.reply('Done All Usernames ')
                    break
        else:
            await msg.edit('Usernames List is empty!')
        


            

bot.run_until_disconnected()